import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemsProComponent } from './items-pro.component';

describe('ItemsProComponent', () => {
  let component: ItemsProComponent;
  let fixture: ComponentFixture<ItemsProComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ItemsProComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemsProComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
